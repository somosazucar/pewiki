#!/bin/sh
sudo rpm -Uvh espeak-1.40.02-2.fc11.i586.rpm pygame-1.8.1-6.fc11.i586.rpm Peru_Learns_English-0.1-1.noarch.rpm  python-greenlet-0.3.1-2.fc11.i586.rpm

