#!/bin/sh
echo Instalando Peru Learns English...
sudo rpm -Uvh espeak-1.40.02-2.fc11.i586.rpm pygame-1.8.1-6.fc11.i586.rpm Peru_Learns_English-0.1-1.noarch.rpm  python-greenlet-0.3.1-2.fc11.i586.rpm SDL-1.2.13-9.1.fc11.i586.rpm SDL_image-1.2.6-7.fc11.i586.rpm SDL_mixer-1.2.8-12.fc11.i586.rpm SDL_ttf-2.0.9-5.fc11.i586.rpm libmikmod-3.2.0-9.beta2.fc11.i586.rpm --force
echo Proceso terminado! El programa aparece en el Menú Aplicaciones -\> Educacion -\> Peru Learns English
